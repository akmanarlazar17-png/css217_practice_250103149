public class FlightBookingFacade {

    private static final String DEFAULT_LOYALTY_TIER = "STANDARD";
    private static final String SILVER_PROMO_CODE     = "SILVER-FREE-BAG";

    private final SeatInventorySystem seatSystem;
    private final BaggagePricingEngine baggageEngine;
    private final CurrencyConverter currencyConverter;
    private final PaymentProcessor paymentProcessor;
    private final TicketIssuer ticketIssuer;

    public FlightBookingFacade() {
        this.seatSystem = new SeatInventorySystem();
        this.baggageEngine = new BaggagePricingEngine();
        this.currencyConverter = new CurrencyConverter();
        this.paymentProcessor = new PaymentProcessor();
        this.ticketIssuer = new TicketIssuer();
    }

    public String bookFlight(String passengerName,
                             String flightCode,
                             String seatNumber,
                             double baseFareUSD,
                             int bagCount,
                             double bagWeightKg,
                             String currency,
                             String cardNumber) {
        return bookFlight(passengerName, flightCode, seatNumber, baseFareUSD,
                bagCount, bagWeightKg, currency, cardNumber, DEFAULT_LOYALTY_TIER);
    }

    public String bookFlight(String passengerName,
                             String flightCode,
                             String seatNumber,
                             double baseFareUSD,
                             int bagCount,
                             double bagWeightKg,
                             String currency,
                             String cardNumber,
                             String loyaltyTier) {

        String lockToken = null;

        try {
            seatSystem.connectToReservationServer();
            lockToken = seatSystem.lockSeat(flightCode, seatNumber, passengerName);
            double totalUSD = baseFareUSD + resolveBaggageFeeUSD(bagCount, bagWeightKg, loyaltyTier);
            double convertedTotal = currencyConverter.convertFromUSD(totalUSD, currency);
            paymentProcessor.initializeGateway();

            if (isSilver(loyaltyTier)) {
                paymentProcessor.applyPromoCode(SILVER_PROMO_CODE);
            }

            String receiptId = paymentProcessor.chargeCard(cardNumber, convertedTotal, currency);
            return ticketIssuer.generateTicket(passengerName, flightCode, lockToken, receiptId);

        } catch (RuntimeException ex) {
            if (lockToken != null) {
                seatSystem.releaseSeatLock(lockToken);
            }
            System.out.println("[Facade] Booking failed for " + passengerName + ": " + ex.getMessage());
            return "BOOKING_FAILED: " + ex.getMessage();
        } finally {
            seatSystem.disconnect();
        }
    }

    private double resolveBaggageFeeUSD(int bagCount, double bagWeightKg, String loyaltyTier) {
        if (isBaggageExempt(loyaltyTier)) {
            System.out.println("[Facade] Loyalty tier " + loyaltyTier.trim().toUpperCase()
                    + " — baggage fee waived.");
            return 0.0;
        }
        return baggageEngine.calculateBaggageFeeUSD(bagCount, bagWeightKg);
    }

    private boolean isBaggageExempt(String loyaltyTier) {
        return "SILVER".equalsIgnoreCase(loyaltyTier) || "GOLD".equalsIgnoreCase(loyaltyTier);
    }

    private boolean isSilver(String loyaltyTier) {
        return "SILVER".equalsIgnoreCase(loyaltyTier);
    }
}